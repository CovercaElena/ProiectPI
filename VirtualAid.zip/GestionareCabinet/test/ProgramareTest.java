/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Elena
 */
public class ProgramareTest {
    
    public ProgramareTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getData method, of class Programare.
     */
    @Test
    public void testGetData() {
        System.out.println("getData");
        Programare instance = new Programare("12/11/2022","11:22-12:00","IOnescu","POpescu");
        String expResult = "12/11/2022";
        String result = instance.getData();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setData method, of class Programare.
     */
    @Test
    public void testSetData() {
        System.out.println("setData");
        String data = "13/09/2022";
        Programare instance = new Programare();
        instance.setData(data);
        String result = instance.getData();
         assertEquals(data, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOraIn method, of class Programare.
     */
    @Test
    public void testGetOraIn() {
        System.out.println("getOraIn");
   Programare instance = new Programare("12/11/2022","11:22-12:00","IOnescu","POpescu");
        String expResult = "11:22-12:00";
        String result = instance.getOraIn();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setOraIn method, of class Programare.
     */
    @Test
    public void testSetOraIn() {
        System.out.println("setOraIn");
        String oraIn = "12";
        Programare instance = new Programare("12/11/2022","11:22-12:00","IOnescu","POpescu");
        instance.setOraIn(oraIn);
        String result = instance.getOraIn();
         assertEquals(oraIn, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   

    /**
     * Test of getMedic method, of class Programare.
     */
    @Test
    public void testGetMedic() {
        System.out.println("getMedic");
        Programare instance = new Programare("12/11/2022","11:22-12:00","Ionescu","Popescu");
        String expResult = "Ionescu";
        String result = instance.getMedic();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMedic method, of class Programare.
     */
    @Test
    public void testSetMedic() {
        System.out.println("setMedic");
        String medic = "Vasilescu";
        Programare instance = new Programare();
        instance.setMedic(medic);
         String result = instance.getMedic();
          assertEquals(medic, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPacient method, of class Programare.
     */
    @Test
    public void testGetPacient() {
        System.out.println("getPacient");
        Programare instance = new Programare("12/11/2022","11:22-12:00","Ionescu","Popescu");
        String expResult = "Popescu";
        String result = instance.getPacient();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPacient method, of class Programare.
     */
    @Test
    public void testSetPacient() {
        System.out.println("setPacient");
        String pacient = "Popescu";
        Programare instance = new Programare();
        instance.setPacient(pacient);
        String result = instance.getPacient();
        assertEquals(pacient, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    
}

import java.util.*;
public class Personal extends User{
	
	String name;
	
	public Personal()
	{
		super();
		name="";
	}
	
	public Personal(String username, String passwd,String name)
	{
		super(username, passwd);
		this.name=name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Personal [name=" + name + "]";
	}
	

}

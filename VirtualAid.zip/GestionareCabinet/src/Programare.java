import java.util.*;
public class Programare {
	public Programare(String data, String oraInOut, String medic, String pacient) {
		super();
		this.data = data;
		this.oraIn = oraInOut;
		this.medic=medic;
                this.pacient=pacient;
	}
	private String data;
	private String oraIn;

	
	private String medic;
	private String pacient;
	public Programare()
	{
		data="";
		oraIn="";
		
		
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getOraIn() {
		return oraIn;
	}
	public void setOraIn(String oraIn) {
		this.oraIn = oraIn;
	}
	
	
	public String getMedic() {
		return medic;
	}
	public void setMedic(String medic) {
		this.medic = medic;
	}
	public String getPacient() {
		return pacient;
	}
	public void setPacient(String pacient) {
		this.pacient = pacient;
	}
	@Override
	public String toString() {
		return "Programare [data=" + data + ", oraIn=" + oraIn  
				+ ", medic=" + medic + ", pacient=" + pacient + "]";
	}

}

import java.util.*;
public class Medic extends User {
	
	public Medic() {
		super();
		
	}
	public Medic(String username, String passwd,String nume,  String specializare,List<Programare>programari) {
		super(username,passwd);
		this.nume = nume;
		
		this.specializare = specializare;
		this.programari=programari;	}
        
        public Medic(String username, String passwd,String nume,  String specializare) {
		super(username,passwd);
		this.nume = nume;
		
		this.specializare = specializare;
			}
        
        
	private String nume;
	
	private String specializare;
	private List<Programare>programari;
	public List<Programare> getProgramari() {
		return programari;
	}
	public void setProgramari(List<Programare> programari) {
		this.programari = programari;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	
	public String getSpecializare() {
		return specializare;
	}
	public void setSpecializare(String specializare) {
		this.specializare = specializare;
	}
	@Override
	public String toString() {
		return "Medic [nume=" + nume + ", specializare=" + specializare + "]";
	}
	
	

}

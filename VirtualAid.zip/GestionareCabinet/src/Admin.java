import java.util.*;
public class Admin extends User {
	public Admin() {
		super();
		rol="admin";
	}

	public Admin(String username, String passwd, String rol) {
		super(username, passwd);
		this.rol=rol;
		
	}

	private String rol;

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	@Override
	public String toString() {
		return super.toString()+ " Admin [rol=" + rol + "]";
	}
	

}

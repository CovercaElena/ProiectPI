import java.util.*;
public class Pacient extends User{
	public Pacient() {
		super();
		nume="nimeni";
		
		varsta=0;
		diagnostic="";
		istoric="";
	}
	public Pacient(String username, String passwd,String nume, Gen gen, int varsta, String diagnostic, String istoric,List<Programare>programari) {
		super(username, passwd);
		this.nume=nume;
	
		this.gen=gen;
		this.varsta=varsta;
		this.diagnostic=diagnostic;
		this.istoric=istoric;
		this.programari=programari;
	
	}
        public Pacient(String username, String passwd,String nume, Gen gen, int varsta, String diagnostic, String istoric) {
		super(username, passwd);
		this.nume=nume;
	
		this.gen=gen;
		this.varsta=varsta;
		this.diagnostic=diagnostic;
		this.istoric=istoric;
        
	
	}
        
        
	private String nume;
	
	public enum Gen
	{
		masculin,feminin;
	}
	private Gen gen;
	private int varsta;
	private String diagnostic;
	private String istoric;
	private List<Programare>programari;
	public List<Programare> getProgramari() {
		return programari;
	}
	public void setProgramari(List<Programare> programari) {
		this.programari = programari;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	
	public Gen getGen() {
		return gen;
	}
	public void setGen(Gen gen) {
		this.gen = gen;
	}
	public int getVarsta() {
		return varsta;
	}
	public void setVarsta(int varsta) {
		this.varsta = varsta;
	}
	public String getDiagnostic() {
		return diagnostic;
	}
	public void setDiagnostic(String diagnostic) {
		this.diagnostic = diagnostic;
	}
	public String getIstoric() {
		return istoric;
	}
	public void setIstoric(String istoric) {
		this.istoric = istoric;
	}
	@Override
	public String toString() {
		return "Pacient [nume=" + nume  + ", gen=" + gen + ", varsta=" + varsta
				+ ", diagnostic=" + diagnostic + ", istoric=" + istoric + "]";
	}

}

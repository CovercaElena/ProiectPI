

import java.awt.image.BufferedImage;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class QRText {
    public static void Send(String text) {
       
        int width = 200; // latimea QR
        int height = 200; // inaltimea QR

        try {
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, width, height);

            // convert bitMatrix to bufferedImage 
            BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(bitMatrix);
            // image-ul poate fi afisat sau procesat acum
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
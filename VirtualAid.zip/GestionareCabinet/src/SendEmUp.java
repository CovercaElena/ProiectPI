import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class SendEmUp {
    public static void sendEmail(JTextField toLabel,String medic,JTextField Nume) {
        String to = toLabel.getText();
        String from = "virtual.aid1@gmail.com";
        String nume=Nume.getText();
        

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("virtual.aid1@gmail.com", "lpszufdyyyimyipf");
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Virtual Aid");
            message.setText("Bine ati venit la Virtual Aid! Va multumim pentru incredere.\nVa anuntam ca planul dumneavoastra de tratament a fost actualizat de catre medicul "+medic+"\nPuteti consulta schimbarile in contul dumneavoastra");

            Transport.send(message);
            System.out.println("Email sent successfully");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }
}

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class SendEmail {
    public static void sendEmail(JTextField toLabel,JTextField Password,JTextField Nume) {
        String to = toLabel.getText();
        String from = "virtual.aid1@gmail.com";
        String nume=Nume.getText();
        String passwd=Password.getText();

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("virtual.aid1@gmail.com", "lpszufdyyyimyipf");
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Virtual Aid");
            message.setText("Bine ati venit la Virtual Aid! Va multumim pentru incredere.\nDetaliile contului dumneavoastra sunt urmatoarele:\nNume: "+nume+"\nParola: "+passwd);

            Transport.send(message);
            System.out.println("Email sent successfully");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }
    
    public static void Forgot(String nume, String email, String password )
    {
        String to=email;
        String from = "virtual.aid1@gmail.com";
         Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("virtual.aid1@gmail.com", "lpszufdyyyimyipf");
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Virtual Aid");
            message.setText("Bine ati venit la Virtual Aid! Va multumim pentru incredere.\nVa reamintim ca detaliile contului dumneavoastra sunt urmatoarele:\nEmail: "+to+"\nNume: "+nume+"\nParola: "+password);

            Transport.send(message);
            System.out.println("Email sent successfully");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
        
    
    
        
        
    }
}
